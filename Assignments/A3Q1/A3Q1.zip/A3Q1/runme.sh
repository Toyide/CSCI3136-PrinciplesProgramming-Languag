#!/bin/sh

# Provide the command here to run your scanner
# example to run a scanner written for python v3
python3 A3.py 

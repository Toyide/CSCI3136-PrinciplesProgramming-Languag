#!/bin/sh
# if your implementation requires compilation include the command here
# javac SchemeEval2.java

# Command to run your program
python3 splat.2.py
